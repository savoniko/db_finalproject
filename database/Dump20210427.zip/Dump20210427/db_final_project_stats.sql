-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: db_final_project
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stats`
--

DROP TABLE IF EXISTS `stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stats` (
  `stat_id` int NOT NULL AUTO_INCREMENT,
  `points_per_game` double DEFAULT NULL,
  `rebounds_per_game` double DEFAULT NULL,
  `assists_per_game` double DEFAULT NULL,
  `field_goal_percentage` double DEFAULT NULL,
  `three_pt_field_goal_percentage` double DEFAULT NULL,
  `free_throw_percentage` double DEFAULT NULL,
  `steals_per_game` double DEFAULT NULL,
  `blocks_per_game` double DEFAULT NULL,
  `player_id` int DEFAULT NULL,
  PRIMARY KEY (`stat_id`),
  KEY `stats_to_player_idx` (`player_id`),
  CONSTRAINT `stats_to_player` FOREIGN KEY (`player_id`) REFERENCES `players` (`player_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stats`
--

LOCK TABLES `stats` WRITE;
/*!40000 ALTER TABLE `stats` DISABLE KEYS */;
INSERT INTO `stats` VALUES (2,13.1,3.3,4.4,43.4,33.9,81.1,0.6,0.2,4),(3,27.5,4.8,6.1,51.5,39.5,91.3,1.3,0.6,5),(4,26.4,4.4,5.2,43.8,38.6,84.5,1,0.3,6),(5,23.6,6.3,5.5,47.9,43.7,89.1,1.2,0.5,7),(6,100,20,10,60,80,95,4,3,NULL),(13,25.7,7.4,4.3,45.3,38.3,86.9,1.2,0.4,3),(14,24.4,5.8,3.4,49.3,40.2,75.7,1.2,0.5,8),(15,100,100,100,100,100,100,100,100,20),(16,18.2,3.9,5,40.9,34.8,91.8,1.1,0.3,11),(17,21.5,7,7.3,49.4,21.3,86.1,2.1,0.4,12),(18,19.1,9.1,5.3,56.8,25,80.4,1.1,1.1,13),(19,27.5,6.7,5.2,54.4,46.7,87,0.6,1.3,14),(20,25.2,8,10.9,46.3,35.8,87,1.3,0.7,15),(21,15.6,3.8,1.9,42,38.3,87.3,0.6,0,16),(22,14.5,13.5,1.3,67.6,0,61.7,0.5,2.8,17),(23,9.1,7.3,1.2,64.3,0,78.8,0.4,0.9,18),(24,25.7,6.7,5.1,51.6,39.3,87.8,1.7,0.4,19);
/*!40000 ALTER TABLE `stats` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-27 20:35:17
