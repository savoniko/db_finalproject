-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: db_final_project
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `players` (
  `player_id` int NOT NULL AUTO_INCREMENT,
  `jersey_number` int NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `profile_picture` varchar(256) DEFAULT NULL,
  `team_id` int NOT NULL,
  `position_id` int DEFAULT NULL,
  PRIMARY KEY (`player_id`),
  KEY `teamId_idx` (`team_id`),
  KEY `positionId_idx` (`position_id`),
  CONSTRAINT `player_to_position` FOREIGN KEY (`position_id`) REFERENCES `positionNames` (`positionNameId`),
  CONSTRAINT `player_to_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`teamId`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `players`
--

LOCK TABLES `players` WRITE;
/*!40000 ALTER TABLE `players` DISABLE KEYS */;
INSERT INTO `players` VALUES (3,0,'Jayson','Tatum','jtatum','password','jtatum@celtics.com','1998-03-03','https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/4065648.png&w=350&h=254',1,3),(4,0,'Goran','Dragic','gdragic','password','gdragic@miami.com','1986-05-06','https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/3423.png&w=350&h=254',2,1),(5,11,'Kyrie','Irving','kirving','password','kirving@nets.com','1992-03-23','https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/6442.png&w=350&h=254',3,1),(6,45,'Donovan','Mitchell','dmitchell','password','dmitchell@jazz.com','1996-09-07','https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/3908809.png&w=350&h=254',4,1),(7,13,'Paul','George','pgeorge','password','pgeorge@clippers.com','1990-05-02','https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/4251.png&w=350&h=254',5,3),(8,7,'Jaylen','Brown','jbrown','password','jaylon@adg.com','1996-10-24','https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/3917376.png&w=350&h=254',1,2),(11,8,'Kemba','Walker','kwalker','password',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/6479.png&w=350&h=254',1,1),(12,22,'Jimmy','Butler','jbutller','password',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/6430.png&w=350&h=254',2,2),(13,13,'Bam','Adebayo','badebayo','password',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/4066261.png&w=350&h=254',2,5),(14,7,'Kevin','Durant','kdurant','password',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/3202.png&w=350&h=254',3,3),(15,13,'James','Harden','jharden','password',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/3992.png&w=350&h=254',3,2),(16,44,'Bojan','Bogdanovic','bbogdanovic','password',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/3593.png&w=350&h=254',4,3),(17,27,'Rudy','Gobert','rgobert','password1234',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/3032976.png&w=350&h=254',4,5),(18,40,'Ivica','Zubac','izubac','password',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/4017837.png&w=350&h=254',5,5),(19,0,'Kawhi','Leonard','kleonard','password',NULL,NULL,'https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/6450.png&w=350&h=254',5,2),(20,17,'Jose','Annunziato','jannunzi','P@ssw0rd!',NULL,NULL,'https://i.imgur.com/FuF0z1y.png',1,3);
/*!40000 ALTER TABLE `players` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-27 20:35:18
